# FlashQR

A Pen created on CodePen.

Original URL: [https://codepen.io/Kh-Kj/pen/NPPEqap](https://codepen.io/Kh-Kj/pen/NPPEqap).

